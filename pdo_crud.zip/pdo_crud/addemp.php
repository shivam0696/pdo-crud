
<?php 
include('includes/config.php'); 
include('includes/function.php'); 
$db = getDB();
$NowDateTime=date("Y-m-d H:i:s");
$baseUrl="upload";

// Save Book Details
if(isset($_POST['add_emp']))
{
    
  try 
  {	
	  if($_POST['name']!=NULL){$name= trim(strip_tags($_POST['name']));}else{$name='';}
      if($_POST['email']!=NULL){$email=trim(strip_tags($_POST['email']));}else{$email='';}
      if($_POST['c_id']!=NULL){$c_id=intval($_POST['c_id']);}else{$c_id='';}
      if($_POST['mobile']!=NULL){$mobile=intval($_POST['mobile']);}else{$mobile='';}

	  $stmt = $db->prepare("SELECT * FROM employee WHERE email=:email"); 
	  $stmt->bindParam(":email", $email,PDO::PARAM_STR);
	  $stmt->execute();
	  $countRow=$stmt->rowCount();
	  
	 if($countRow>0)
	  {
		  $_SESSION['status']="error";
	      $_SESSION['action']="Email  has been already taken !!!";
	      msg_redirect("".$_SESSION['action']."","index.php","0");
	      exit();	
	  }

      else if($_POST['email']=='' && $_POST['email']==NULL)
	  {
		  $_SESSION['status']="error";
		  $_SESSION['action']="Employee email input field is required!";
		  msg_redirect("".$_SESSION['action']."","index.php","0");
		  exit();
	  }
	  else
	  {	

        if($_FILES['image']['name']!='')
		{
		  $fileName = $_FILES['image']['name'];
		  $ext = pathinfo($fileName, PATHINFO_EXTENSION);  
		  $image = 'img-'.time().rand(0,999).'.'.$ext; 
		  $baseUrl = 'upload';
		  $user_dir_path = $baseUrl . '/' . $image;
		  copy($_FILES['image']['tmp_name'],$user_dir_path);
		}
	
		  $stmt = $db->prepare("INSERT INTO employee(name,email,mobile,c_id,image,created_at)VALUES(:name,:email,:mobile,:c_id,:image,:created_at)");
		  $stmt->bindParam(":name", $name,PDO::PARAM_STR);
          $stmt->bindParam(":email", $email,PDO::PARAM_STR);
          $stmt->bindParam(":mobile", $mobile,PDO::PARAM_INT);
          $stmt->bindParam(":c_id", $c_id,PDO::PARAM_INT);
          $stmt->bindValue(':image', !empty($image) ? $image : NULL, PDO::PARAM_STR);
          $stmt->bindParam(':created_at', $NowDateTime,PDO::PARAM_STR);
		  $stmt->execute();
		  $count=$stmt->rowCount();
		  if($count>0)
		  {
			 $_SESSION['status']="success";
			 $_SESSION['action']="Employee details has been added successfully.";
	         msg_redirect("".$_SESSION['action']."","index.php","0");
	         exit();
		  }
	  }
  }
  catch (PDOException $e) 
  {
    $error = $e->getMessage ();
	$_SESSION['status']="error";
	$_SESSION['action']=$error;
	msg_redirect("".$_SESSION['action']."","index.php","0");
	exit();
   }
}

   

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Employee</title>
    <link href=" https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="py-3">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header">
                        <h5>Add New Employee Detils Form</h5>
                        <a href="index.php" class="btn btn-danger float-end">Back</a>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST" enctype='multipart/form-data'>
                            <div class="formgroup">
                                <label for="">Name</label>
                                <input type="text" name="name" class="form-control">
                            </div>

                            <div class="form-group mb-3">
                                <label for="">Phone</label>
                                <input type="text" name="mobile" class="form-control">
                            </div>

                            <div class="form-group mb-3">
                                <label for="">Email Address</label>
                                <input type="text" name="email" class="form-control">
                            </div>
                            <div class="form-group mb-3">
                            <label for="">City</label>
                            <select id="c_id" class="form-control" name="c_id" required>
                            <option value="">Select City</option>
                            <?php //fetch record for City
                            $stmtVivechak = $db->prepare("SELECT c_id,c_name FROM city");
                            $stmtVivechak->execute(); 
                            $VivArray = $stmtVivechak->fetchAll();
                            foreach($VivArray as $VivList){?>
                            <option value="<?php echo $VivList['c_id'];?>"<?php if($VivList['c_id']==$c_id){echo "selected=\"selected\"";}?>><?php echo $VivList['c_name'];?></option>
                            <?php }?>
                            </select>
                            </div>

                            <div class="form-group mb-3">
                                <label for=""> image</label>
                                <input type="file" class="form-control" name="image" id="image" onChange="return myPhoto()" />
                                <small style="color:#F00;">Upload jpg,jpeg images only, Maximum size 30KB.</small>
                            </div>
                            <div class="form-group">
                                <button type="submit" name="add_emp" class="btn btn-primary">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<script language="javascript">
function myPhoto(){
var file = document.getElementById("image");
var file_name = file.value;
var extension = file_name.split('.').pop().toLowerCase();
var size      = file.files[0].size;
var fName     = file.files[0].name;
var allowedFormats = ["jpg", "jpeg"];
//alert(fName);
if(!(allowedFormats.indexOf(extension) > -1))
{
 alert("Please upload jpg and jpeg files only!");
 document.getElementById("image").value='';
 document.getElementById("image").focus();
 return false;              
}
else if(fName.length>52)
{
  alert("Filename exceeds 52 characters!");
  document.getElementById("image").value='';
  document.getElementById("image").focus();
  return false;   	
}
else if((size/1024)>30)
{
   alert("Your file should be less than or equal to 30KB!");
   document.getElementById("image").value='';
   document.getElementById("image").focus();
   return false;
} 
}
</script>