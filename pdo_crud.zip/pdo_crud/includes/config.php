
<?php 
error_reporting(0);
session_start();
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'pdo_crud');
define("BASE_URL", "http://localhost/pdo_crud/");?>