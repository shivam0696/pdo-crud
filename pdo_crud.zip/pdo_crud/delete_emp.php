<?php
include('includes/config.php'); 
include('includes/function.php'); 
$db = getDB();
$RedURL=$_POST['source'];
//update record
if(isset($_POST['submit']))
{
 try
 {
   if(hash_equals($_POST['mytoken'],$_SESSION['mytoken'])===false)
   {
	  $_SESSION['status']="error";
	  $_SESSION['action']="Secret key missing!";
	  msg_redirect("".$_SESSION['action']."","".$RedURL."","0");
	  exit();
   }
   else
   {
	  $stmt = $db->prepare("DELETE FROM employee WHERE id=:id");
	  $stmt->bindParam(':id', $id, PDO::PARAM_INT); 
	  $stmt->execute();
	  $count=$stmt->rowCount();
	  if($count>0)
	  {
		 $_SESSION['status']="success";
		 $_SESSION['action']="Record has been deleted successfully.";
		 msg_redirect("".$_SESSION['action']."","".$RedURL."","0");
		 exit();
	  }
    }
  }
  catch(PDOException $e) 
  {
	  $error = $e->getMessage();
	  $_SESSION['status']="warning";
	  $_SESSION['action']="You can not delete this record because it is used in another table !!!";
	  msg_redirect("".$_SESSION['action']."","".$RedURL."","0");
	  exit();
  } 	
}?>
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
  <h4><i class="fa fa-trash"></i> Delete Record</h4>
</div>
<form action="delete_emp.php" method="post" name="frmupload">
<div class="modal-body">
<input type="hidden" name="mytoken" value="<?php echo $_POST['mytoken'];?>" />
<input type="hidden" name="source" value="<?php echo $_POST['source'];?>" />
<input type="hidden" name="id" value="<?php echo $_POST['id'];?>" />
  <p>Are you sure you want to delete this record...!</p>
</div>
<div class="modal-footer">
  <button type="button" class="btn btn-info btn-sm" data-dismiss="modal">Cancel</button>
  <button type="submit" class="btn btn-danger btn-sm" name="submit"><i class="fa fa-trash"></i> Delete</button>
</div>
</form>