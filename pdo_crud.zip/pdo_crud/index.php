
<?php 
include('includes/config.php'); 
include('includes/function.php'); 
$db = getDB();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pdo Crud</title>
    <link href=" https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-12">
<!-- SESSION MESSAGE -->
      <?php if($_SESSION['action'] != NULL && $_SESSION['status'] != NULL) { ?>
      <div class="alert 
          <?php if($_SESSION['status'] == 'success') { ?>alert-success<?php } else if($_SESSION['status'] == 'error') { ?>alert-danger<?php } else { ?>alert-warning<?php } ?>
          alert-dismissible fade show" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <h4 class="alert-heading">
          <?php if($_SESSION['status'] == 'success') { ?><i class="icon fa fa-check"></i><?php } else { ?><i class="icon fa fa-exclamation-triangle"></i><?php } ?>
          <?php if($_SESSION['status'] == 'success') { ?>Success<?php } else if($_SESSION['status'] == 'error') { ?>Error!<?php } else { ?>Alert<?php } ?>
        </h4>
        <?php echo $_SESSION['action']; $_SESSION['action'] = NULL; ?>
      </div>
    <?php } ?>
  <!-- SESSION MESSAGE -->

      <!-- Pop Model -->
      <div class="modal fade" id="globalModal" tabindex="-1" role="dialog" aria-labelledby="esModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content"></div>
    </div>
  </div>
  <!-- Pop Model -->


      <div class="card">
        <div class="card-header">
          <h4 class="text-center"><strong>Manage Employee Details</strong></h4>
          <a href="addemp.php" class="btn btn-success float-end">Add Employee</a>
        
        </div>
        <div class="card-body">
    <table class="table table-striped border-dark">
        <thead>
            <tr>
                <th >NAME.</th>
                <th>EMAIL</th>
                <th>MOBILE</th>
                <th>CITY</th>
                <th>IMAGE</th>
                <th class="text-center">Action</th>
            </tr>
        </thead>
        <tbody>

            <?php 
            // Feth Data From Books Table
            $db = getDB();
            $sq = $db->prepare("SELECT * FROM employee");
            $sq->execute(); 
            $rows = $sq->fetchAll();
            $NumRows = count($rows); 
            if($NumRows > 0) {
            foreach($rows as $row) {
              $id=$row['id'];
            ?>
              <tr>
                  <td><?php echo $row['name']; ?></td>
                  <td><?php echo $row['email']; ?></td>
                  <td><?php echo $row['mobile']; ?></td>
                  <td><?php echo CityName($row['c_id']); ?></td>
                  <td><img src="upload/<?php echo htmlspecialchars($row['image']); ?>" alt="Image" width="100px"></td>
                  <td class="text-center">
                  <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-warning" title="Edit Record">Edit</a>
                  <a class="btn btn-danger btn-xs" data-toggle="tooltip" data-placement="left" data-toggle="tooltip" title="Delete Record" href="javascript:void(0);" onClick="deleteRecord('$id');return false;">Delete</a>
                  </td>
              </tr>
              <?php
                }
            } else {
                ?>
                <tr>
                    <td colspan="7">
                    <div class="table-responsive">
                        <div class="alert alert-danger" role="alert">
                            <i class="bi bi-exclamation-triangle"></i> No Employee available ..
                        </div>
                    </div>
                    </td>
                </tr>
                <?php
            }
            ?>
              </tbody>
          </table>
      </div>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</body>
</html>

<script type="text/javascript">
function deleteRecord(id) {
$.ajax({
  type:'POST',
  url:'delete_emp.php',
  data:{ 'id' : id,  'source' : 'index.php'},
  success: function(data)
  {
	$('.modal-content').html(data);
	$('#globalModal').modal();
  }
});
}
</script>